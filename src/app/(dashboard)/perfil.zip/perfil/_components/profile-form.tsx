"use client";

import { useState, useEffect } from "react";
import type { ProfileVM } from "../_types/profile-types";

export function ProfileForm({ vm, action }: { vm: ProfileVM; action: string }) {
  const [flash, setFlash] = useState<string | null>(null);

  // Para mostrar mensajes temporales
  useEffect(() => {
    if (!flash) return;
    const t = window.setTimeout(() => setFlash(null), 3500);
    return () => window.clearTimeout(t);
  }, [flash]);

  return (
    <form
      action={action}
      method="post"
      className="max-w-3xl mx-auto rounded-2xl border border-rose-100 bg-white p-6 shadow-sm space-y-6"
    >
      <h2 className="text-lg font-extrabold text-neutral-900">Información personal</h2>
      <p className="text-sm text-neutral-600">
        Actualiza tu nombre, contacto y fecha de nacimiento.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-1">
          <label className="text-sm font-semibold text-neutral-800">Nombre</label>
          <input
            name="firstName"
            defaultValue={vm.firstName}
            placeholder="Ej: Juan"
            className="input"
          />
        </div>

        <div className="space-y-1">
          <label className="text-sm font-semibold text-neutral-800">Apellido</label>
          <input
            name="lastName"
            defaultValue={vm.lastName}
            placeholder="Ej: Pérez"
            className="input"
          />
        </div>

        <div className="space-y-1">
          <label className="text-sm font-semibold text-neutral-800">Teléfono</label>
          <input
            name="phoneNumber"
            defaultValue={vm.phoneNumber ?? ""}
            placeholder="Ej: 71234567"
            className="input"
          />
        </div>

        <div className="space-y-1">
          <label className="text-sm font-semibold text-neutral-800">Fecha de nacimiento</label>
          <input
            type="date"
            name="dateOfBirth"
            defaultValue={vm.dateOfBirth ?? ""}
            className="input"
          />
        </div>
      </div>

      <div className="flex justify-between items-center">
        <div className="text-sm text-neutral-700">
          Estado: <span className="font-semibold">{vm.isActive ? "Activo" : "Inactivo"}</span>{" "}
          · Rol: <span className="font-semibold">{vm.roleName ?? "—"}</span>
        </div>
        <button type="submit" className="btn-primary">
          Guardar cambios
        </button>
      </div>

      {flash && <p className="text-rose-700 font-semibold">{flash}</p>}
    </form>
  );
}