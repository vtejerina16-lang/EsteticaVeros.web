// src/app/(dashboard)/perfil/_types/profile-types.ts

export type BackendUserDto = {
  id: number | string;
  firstName: string;
  lastName: string;
  phoneNumber?: string | null;
  address?: string | null;
  dateOfBirth?: string | null; // yyyy-mm-dd
  roleName?: string | null;
  isActive?: boolean;
  email?: string | null;
};

export type ProfileVM = {
  id: string;
  firstName: string;
  lastName: string;
  fullName: string;
  email?: string | null;
  phoneNumber?: string | null;
  address?: string | null;
  dateOfBirth?: string | null;
  roleName?: string | null;
  isActive?: boolean;
};

export type UpdateProfileInput = {
  firstName: string;
  lastName: string;
  phoneNumber?: string | null;
  address?: string | null;
  dateOfBirth?: string | null;
};

export type UpdateProfileActionState = {
  ok: boolean;
  message?: string;
  fieldErrors?: Partial<Record<keyof UpdateProfileInput, string>>;
};