"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { getAccessToken } from "@/lib/auth";
import { HttpError } from "@/lib/http";
import { updateMyProfile } from "@/app/(dashboard)/perfil/_services/profile-service";
import type { UpdateProfileActionState, UpdateProfileInput } from "../_types/profile-types";

// Estado inicial directamente exportable
export const updateProfileInitialState: UpdateProfileActionState = { ok: false };

// Función async para usar con "useActionState"
export async function updateProfileAction(
  _prev: UpdateProfileActionState,
  formData: FormData
): Promise<UpdateProfileActionState> {
  const token = await getAccessToken();
  if (!token) redirect("/login");

  const input: UpdateProfileInput = {
    firstName: (formData.get("firstName") as string) ?? "",
    lastName: (formData.get("lastName") as string) ?? "",
    phoneNumber: ((formData.get("phoneNumber") as string) || "").trim() || null,
    address: ((formData.get("address") as string) || "").trim() || null,
    dateOfBirth: ((formData.get("dateOfBirth") as string) || "").trim() || null,
  };

  const errors: UpdateProfileActionState["fieldErrors"] = {};

  if (!input.firstName) errors.firstName = "El nombre es obligatorio.";
  if (!input.lastName) errors.lastName = "El apellido es obligatorio.";
  if (input.firstName.length > 50) errors.firstName = "Máximo 50 caracteres.";
  if (input.lastName.length > 50) errors.lastName = "Máximo 50 caracteres.";
  if (input.phoneNumber && input.phoneNumber.length > 20) errors.phoneNumber = "Máximo 20 caracteres.";
  if (input.address && input.address.length > 200) errors.address = "Máximo 200 caracteres.";
  if (input.dateOfBirth && !/^\d{4}-\d{2}-\d{2}$/.test(input.dateOfBirth)) errors.dateOfBirth = "Fecha inválida (YYYY-MM-DD)";

  if (Object.keys(errors).length) {
    return { ok: false, message: "Revisa los campos marcados.", fieldErrors: errors };
  }

  try {
    await updateMyProfile(token, input);
    revalidatePath("/perfil");
    return { ok: true, message: "Perfil actualizado correctamente." };
  } catch (e) {
    if (e instanceof HttpError) return { ok: false, message: `Error al guardar (${e.status}).` };
    return { ok: false, message: "Error inesperado al guardar." };
  }
}