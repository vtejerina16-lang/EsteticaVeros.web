// src/app/(dashboard)/perfil/_actions/profile-actions-types.ts
import type { UpdateProfileActionState } from "../_types/profile-types";

export const updateProfileInitialState: UpdateProfileActionState = { ok: false };