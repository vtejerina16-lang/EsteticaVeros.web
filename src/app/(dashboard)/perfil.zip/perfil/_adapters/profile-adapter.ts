// src/app/(dashboard)/perfil/_adapters/profile-adapter.ts
import type { BackendUserDto, ProfileVM, UpdateProfileInput } from "../_types/profile-types";

function toDateInputValue(value?: string | null): string | null {
  if (!value) return null;
  const m = String(value).match(/^(\d{4}-\d{2}-\d{2})/);
  return m ? m[1] : null;
}

export function toProfileVM(dto: BackendUserDto): ProfileVM {
  return {
    id: String(dto.id),
    firstName: dto.firstName ?? "",
    lastName: dto.lastName ?? "",
    fullName: `${dto.firstName ?? ""} ${dto.lastName ?? ""}`.trim() || "Usuario",
    email: dto.email ?? null,
    phoneNumber: dto.phoneNumber ?? null,
    address: dto.address ?? null,
    dateOfBirth: toDateInputValue(dto.dateOfBirth),
    roleName: dto.roleName ?? null,
    isActive: dto.isActive ?? true,
  };
}

export function toUpdatePayload(current: BackendUserDto, input: UpdateProfileInput) {
  return {
    firstName: input.firstName,
    lastName: input.lastName,
    phoneNumber: input.phoneNumber ?? null,
    address: input.address ?? null,
    dateOfBirth: input.dateOfBirth ?? null,
    roleName: current.roleName ?? "Receptionist",
    isActive: current.isActive ?? true,
  };
}