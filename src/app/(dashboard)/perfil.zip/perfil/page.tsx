import "server-only";
import { redirect } from "next/navigation";
import { getAccessToken } from "@/lib/auth";
import { getMyProfile } from "./_services/profile-service";
import { toProfileVM } from "./_adapters/profile-adapter";
import { ProfileForm } from "./_components/profile-form";

export const dynamic = "force-dynamic";

export default async function PerfilPage() {
  const token = await getAccessToken();
  if (!token) redirect("/login");

  const dto = await getMyProfile(token);
  const vm = toProfileVM(dto);

  return (
    <section className="max-w-4xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-extrabold text-neutral-900">Mi perfil</h1>
      <ProfileForm vm={vm} action="/api/profile/update" />
    </section>
  );
}