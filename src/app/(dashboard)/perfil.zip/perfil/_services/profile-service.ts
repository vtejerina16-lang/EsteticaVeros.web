// src/app/(dashboard)/perfil/_services/profile-service.ts
import type { BackendUserDto, UpdateProfileInput } from "../_types/profile-types";
import { fetchJson } from "@/lib/http";

export async function getMyProfile(token: string): Promise<BackendUserDto> {
  return await fetchJson(`/api/users/me`, { token });
}

export async function updateMyProfile(token: string, input: UpdateProfileInput): Promise<BackendUserDto> {
  const current = await getMyProfile(token);
  const payload = {
    ...input,
    roleName: current.roleName ?? "Receptionist",
    isActive: current.isActive ?? true,
  };
  return await fetchJson(`/api/users/${current.id}`, {
    method: "PUT",
    token,
    body: payload,
  });
}